import csv
import hashlib
import random


class Account:
    def register(self):
        """Register a new user"""

        phone = input("Enter phone number: ")
        pin = input("Enter PIN: ")

        # hash the pin
        hashed_pin = hashlib.sha256(pin.encode()).hexdigest()

        # generate account number
        account_number = str(random.randint(10000000, 99999999))

        # save to file
        with open("account_balances.txt", "a", newline="") as file:
            writer = csv.writer(file)
            writer.writerow([account_number, phone, hashed_pin, 0])

        print("Registration successful!")
        print("Your account number is:", account_number)

    def login(self):
        """Login user"""

        phone = input("Enter phone: ")
        pin = input("Enter PIN: ")

        hashed_pin = hashlib.sha256(pin.encode()).hexdigest()

        try:
            with open("account_balances.txt", "r") as file:
                reader = csv.reader(file)

                for row in reader:
                    if row[1] == phone and row[2] == hashed_pin:
                        print("Login successful!")
                        return row

        except FileNotFoundError:
            print("No accounts found. Please register first.")

        print("Login failed.")
        return None


