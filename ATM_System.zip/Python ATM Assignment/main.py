from account import Account
from transaction import Transaction

acc = Account()
trans = Transaction()

while True:
    print("\n===== PyBank ATM =====")
    print("1. Register")
    print("2. Login")
    print("3. Exit")

    choice = input("Choose: ")

    if choice == "1":
        acc.register()

    elif choice == "2":
        user = acc.login()

        if user:
            while True:
                print("\n--- Menu ---")
                print("1. Deposit")
                print("2. Withdraw")
                print("3. Transfer")
                print("3. Logout")

                option = input("Choose: ")
                
                if option == "1":
                    trans.deposit(user)
                    
                elif option == "2":
                    trans.withdraw(user)
                    
                elif option == "3":
                    trans.transer(user)
                    
                elif option == "4":
                    print("Logged out.")
                    break
                
                else:
                    print("Invalid choice.")            

        

        

           
