import csv
from datetime import datetime


class Transaction:
    def deposit(self, user):
        """Deposit money"""

        try:
            amount = float(input("Enter amount to deposit: "))
        except ValueError:
            self.record_transaction(user[1], "DEPOSIT", amount, user[3])
            print("Invalid amount.")
            return

        # update balance
        balance = float(user[3])
        new_balance = balance + amount
        user[3] = str(new_balance)

        # update file
        rows = []

        with open("account_balances.txt", "r") as file:
            reader = csv.reader(file)

            for row in reader:
                if row[0] == user[0]:
                    rows.append(user)
                else:
                    rows.append(row)

        with open("account_balances.txt", "w", newline="") as file:
            writer = csv.writer(file)
            writer.writerows(rows)

        print(f"Deposit successful! New balance: R{new_balance}")
        
def withdraw(self, user):
    """Withdraw money"""

    try:
        amount = float(input("Enter amount to withdraw: "))
    except ValueError:
        print("Invalid amount.")
        return

    balance = float(user[3])

    if amount > balance:
        print("Insufficient funds.")
        return

    new_balance = balance - amount
    user[3] = str(new_balance)

    # update file
    rows = []

    with open("account_balances.txt", "r") as file:
        reader = csv.reader(file)

        for row in reader:
            if row[0] == user[0]:
                rows.append(user)
            else:
                rows.append(row)

    with open("account_balances.txt", "w", newline="") as file:
        writer = csv.writer(file)
        writer.writerows(rows)

    print(f"Withdraw successful! New balance: R{new_balance}")
    

def transfer(self, user):
    """Transfer money to another account"""

    target_account = input("Enter recipient account number: ")

    try:
        amount = float(input("Enter amount to transfer: "))
    except ValueError:
        print("Invalid amount.")
        return

    rows = []
    sender_found = False
    receiver_found = False

    with open("account_balances.txt", "r") as file:
        reader = csv.reader(file)

        for row in reader:
            # Sender
            if row[0] == user[0]:
                sender_found = True
                balance = float(row[3])

                if amount > balance:
                    print("Insufficient funds.")
                    return

                row[3] = str(balance - amount)
                self.record_transaction(user[1], "EFT_OUT", amount, user[3])
                user[3] = row[3]

            # Receiver
            elif row[0] == target_account:
                receiver_found = True
                row[3] = str(float(row[3]) + amount)

            rows.append(row)

    if not receiver_found:
        print("Account not found.")
        return

    with open("account_balances.txt", "w", newline="") as file:
        writer = csv.writer(file)
        writer.writerows(rows)

    print("Transfer successful!")    
    
def record_transaction(self, phone, t_type, amount, balance):
    """Save transaction to file"""

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    with open("transactions.txt", "a", newline="") as file:
        writer = csv.writer(file)
        writer.writerow([timestamp, phone, t_type, amount, balance])
        
def transfer(self, user):
    target_account = input("Enter recipient account number: ")

    try:
        amount = float(input("Enter amount to transfer: "))
    except ValueError:
        print("Invalid amount.")
        return

    rows = []
    receiver_found = False

    with open("account_balances.txt", "r") as file:
        reader = csv.reader(file)

        for row in reader:
            # 👇 SENDER
            if row[0] == user[0]:
                balance = float(row[3])

                if amount > balance:
                    print("Insufficient funds.")
                    return

                row[3] = str(balance - amount)
                user[3] = row[3]

                # ✅ ADD IT HERE
                self.record_transaction(user[1], "EFT_OUT", amount, user[3])

            # 👇 RECEIVER
            elif row[0] == target_account:
                receiver_found = True
                row[3] = str(float(row[3]) + amount)

            rows.append(row)

    if not receiver_found:
        print("Account not found.")
        return

    with open("account_balances.txt", "w", newline="") as file:
        writer = csv.writer(file)
        writer.writerows(rows)

    print("Transfer successful!")               